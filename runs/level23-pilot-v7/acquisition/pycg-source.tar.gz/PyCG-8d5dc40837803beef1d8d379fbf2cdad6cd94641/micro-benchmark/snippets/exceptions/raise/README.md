An exception is raised.
