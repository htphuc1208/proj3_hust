A dictionary is returned.
