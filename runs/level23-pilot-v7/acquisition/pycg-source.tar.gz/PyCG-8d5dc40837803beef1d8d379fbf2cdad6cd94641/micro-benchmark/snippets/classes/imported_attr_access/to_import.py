def func():
    pass
