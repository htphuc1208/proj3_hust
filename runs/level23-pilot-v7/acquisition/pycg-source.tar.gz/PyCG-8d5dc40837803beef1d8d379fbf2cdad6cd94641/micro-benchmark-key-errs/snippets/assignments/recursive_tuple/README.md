A recursive tuple assignment.
