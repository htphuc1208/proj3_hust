A chained assignment.
